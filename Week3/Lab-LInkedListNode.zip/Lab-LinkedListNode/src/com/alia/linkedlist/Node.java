package com.alia.linkedlist;

public class Node {
	
	private int data;
	
	private Node next;
	
	//constructor
	public Node(int data, Node next) {
		this.data = this.setData(data);
		this.next = this.setNext(next);
	}
	
	public String toString() {
		return data + "";
	}
	
	//add function
	public Node add(Node node) {
		Node current = this;
		while(current.next != null) {
			current = current.next;
		}
		return node;
	}
	
	//getters and setters
	public int getData(){
		return data;
	}
	
	public int setData(int data){
		this.data = data;
		return data;
	}
	
	public Node getNext(){
		return next;
	}
	
	public Node setNext(Node next){
		this.next = next;
		return next;
	}
}
