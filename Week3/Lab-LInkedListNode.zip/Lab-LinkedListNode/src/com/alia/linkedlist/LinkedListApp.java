package com.alia.linkedlist;

public class LinkedListApp {

	public static void main(String[] args) {
		Node head = new Node(25, null);
		System.out.println(head);
	}

}
