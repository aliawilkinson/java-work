package com.alia.linkedlist;

import com.alia.linkedlist.Node;

public class LinkedListNode {
	private Node next = new Node();
	private int listCount;
	
	//constructor
	public LinkedListNode(){
		next = new Node();
		listCount = 0;
	}
	
	public void add(Object data) {
		Node temp = new Node();
		Node current = next;
		while(current.getNext() != null) {
			current = (Node) current.getNext();
		}
		current.setNext(temp);
		listCount++;
	}

}
