package com.alia.linkedlist;

public class Node {
	private Node next = new Node();
	
	//constructor
	public Node(){
		next = new Node();
	}
	
	//getters and setters
	public Node getNext() {
		return this.next;
	}
	
	public void setNext(Node value) {
		this.next = value;
	}

}
