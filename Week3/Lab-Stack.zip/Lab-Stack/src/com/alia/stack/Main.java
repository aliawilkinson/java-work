package com.alia.stack;

//Driver code 
public class Main { 
	public static void main(String args[]){ 
		Stack s = new Stack(); 
		s.push(1); 
		s.push(2); 
		s.push(3); 
		System.out.println(s.pop() + " Popped from stack"); 
	} 
}