
public class ThisTest {

	public static void main(String[] args) {
		//new instance
		A classA = new A();
		
		//set value of id
		classA.setId(2);
		
		//print value of id
		System.out.println(classA.getId());
	}
}
