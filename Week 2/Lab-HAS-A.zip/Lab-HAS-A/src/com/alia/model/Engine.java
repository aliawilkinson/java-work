package com.alia.model;

public class Engine {
	  
	public void on() {
		    System.out.println("Turning engine on");
		  }

		  public void off(){
		    System.out.println("Turning engine off");
		  }
}
