package model.trolls;

public class AnotherTroll {
	public static void main(String[] args) {
		
	}

}
