package model;

public class Troll {

}
