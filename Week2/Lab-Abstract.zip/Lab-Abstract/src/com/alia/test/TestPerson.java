package com.alia.test;

import com.alia.Person;

public class TestPerson {

	public static void main(String[] args) {
		Person adam = new Person();
	}
}
