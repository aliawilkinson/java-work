package com.alia;

public class FinalClass {
	protected final String type = "Type-A";
    protected final ClassA classA = new ClassA();

    public final void someMethod(){
        System.out.println("Some method");
    }
}
