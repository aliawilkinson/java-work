package com.alia;

public final class ClassB extends ClassA {
	public static void someMethod(int x) {
		System.out.print("Some method");
	}

}
